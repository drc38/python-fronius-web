# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fronius_solarweb', 'fronius_solarweb.schema']

package_data = \
{'': ['*']}

install_requires = \
['httpx>=0.23,<0.24', 'pydantic>=1.10,<2.0', 'tenacity>=8.1,<9.0']

setup_kwargs = {
    'name': 'fronius-solarweb',
    'version': '0.1',
    'description': 'A Python wrapper for the Fronius Solar.web Cloud API',
    'long_description': '# fronius_solarweb\n\nPython client for the Fronius Solar.web API.\n\n## Features \n\n- Talks to your Fronius Solr.web PV system via Cloud API\n- Automatic retries with exponential backoff\n- Optionally pass in a `httpx` client\n\n## Usage\n\n```python\nimport asyncio\nfrom pydantic import BaseSettings, SecretStr\nfrom fronius_solarweb.api import Fronius_Solarweb\n\n\nclass AuthDetails(BaseSettings):\n    ACCESS_KEY_ID: SecretStr\n    ACCESS_KEY_VALUE: SecretStr\n    PV_SYSTEM_ID: str\n\n\nasync def main():\n    creds = AuthDetails()\n    fronius = Fronius_Solarweb(access_key_id=creds.ACCESS_KEY_ID.get_secret_value(),\n                  access_key_value=creds.ACCESS_KEY_VALUE.get_secret_value(),pv_system_id=creds.PV_SYSTEM_ID)\n\n    pv_system_data = await fronius.get_pvsystem_meta_data()\n    devices_data = await fronius.get_devices_meta_data()\n    flow_data = await fronius.get_system_flow_data()\n\n    print("Getting PV system meta data for ", creds.PV_SYSTEM_ID)\n    print(pv_system_data)\n\n    print("Getting Devices meta data")\n    print(devices_data)\n\n    print("Getting power flow data")\n    print(flow_data)\n\n\nif __name__ == \'__main__\':\n    asyncio.run(main())\n```\n\n## Examples\n\n`python-evnex` is intended as a library, but a few example scripts are provided in the `examples` folder.\n\nProviding authentication for the examples is via environment variables, e.g. on nix systems:\n\n```\nexport ACCESS_KEY_ID=FKIAFEF58CFEFA94486F9C804CF6077A01AB\nexport ACCESS_KEY_VALUE=47c076bc-23e5-4949-37a6-4bcfcf8d21d6\nexport PV_SYSTEM_ID=20bb600e-019b-4e03-9df3-a0a900cda689\n\npython -m examples.get_charge_point_detail\n```\n\n\n',
    'author': 'Derek Caudwell',
    'author_email': 'derek_caudwell@hotmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/drc38',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
